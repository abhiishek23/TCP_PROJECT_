export const baseUrl = "https://codeutsava.nitrr.ac.in/server/";
export const currentYear = "2023";
export const previousYear = "2022";
