import Img1 from "../images/glimpses/img1.jpg";
import Img2 from "../images/glimpses/img2.jpg";
import Img3 from "../images/glimpses/img3.jpg";
import Img4 from "../images/glimpses/img4.jpg";
import Img5 from "../images/glimpses/img5.jpg";
import Img7 from "../images/glimpses/img7.jpg";
import Img8 from "../images/glimpses/img8.jpg";
import Img9 from "../images/glimpses/img9.jpg";
import Img10 from "../images/glimpses/img10.jpg";

const glimpses = [
  {
    id: 1,
    imgSrc: Img1,
  },
  {
    id: 2,
    imgSrc: Img2,
  },
  {
    id: 3,
    imgSrc: Img3,
  },
  {
    id: 4,
    imgSrc: Img4,
  },
  {
    id: 5,
    imgSrc: Img5,
  },
  {
    id: 6,
    imgSrc: Img7,
  },
  {
    id: 7,
    imgSrc: Img8,
  },
  {
    id: 8,
    imgSrc: Img10,
  },
];

export default glimpses;
