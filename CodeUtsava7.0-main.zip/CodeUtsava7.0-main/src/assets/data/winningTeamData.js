const winningTeamData = [
  {
    position: "🥇 Winners 🥇",
    "name": "ctrlshifthack",
    "leader": "",
    "member1": "Aman Jain",
    "member2": "K Venkat Nag Sai",
    "member3": "Chinmaya Kumar Das",
    "member4": "Aarif Khan",
    "college": "NIT Raipur"
  },
  {
    position: "🥈 Runner - Up 🥈",
    name: "MinGWx86",
    leader: "",
    member1: "Sachin Jangid",
    member2: "Siddesh Shetty",
    member3: "Omkar Bhostekar",
    member4: "Jash Doshi",
    college: "Thadomal Shahani Engineering College, Mumbai",
  },
  {
    position: "🥉 2ⁿᵈ Runner - Up 🥉",
    name: "Synergy",
    leader: "",
    member1: "Rishita Ghosh",
    member2: "Cm Sushmita",
    member3: "Bhagyalaxmi A",
    member4: "Aman Netam",
    college: "GEC Raipur",
  },
];

export default winningTeamData;
