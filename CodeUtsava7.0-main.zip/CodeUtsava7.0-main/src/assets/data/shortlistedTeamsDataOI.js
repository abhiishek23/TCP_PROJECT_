const shortlistedTeams = [
  {
    "name": "Team Syntax Smashers",
    "leader": "",
    "member1": "Arshad Yasir",
    "member2": "Nitesh Kumar",
    "member3": "Anushk Singh",
    "member4": "",
    "college": "NIT Raipur"
  },
  {
    "name": "Straw Hats",
    "leader": "",
    "member1": "Devesh Agrawal",
    "member2": "Hetharth Sachdeva",
    "member3": "Satyam Tiwari",
    "member4": "Mayank Verma",
    "college": "NIT Raipur"
  },
  {
    "name": "Foresighters",
    "leader": "",
    "member1": "Nikhil Painkara",
    "member2": "Gourav Deep Shahni",
    "member3": "Chandrakant Verma",
    "member4": "Aman Singh",
    "college": "NIT Raipur"
  },
  {
    "name": "QuatumBytes",
    "leader": "",
    "member1": "Rakshith Shetty",
    "member2": "Vishal Agrahari",
    "member3": "Tanmay Srivastava",
    "member4": "Pratyaksh Singh",
    "college": "NIT Raipur"
  },
  {
    "name": "Kirmada",
    "leader": "",
    "member1": "Karan Manglani",
    "member2": "Shaurya Bansal",
    "member3": "Arun Rathaur",
    "college": "NIT Raipur"
  },
];

export default shortlistedTeams;
