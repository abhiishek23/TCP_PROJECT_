import sponser1 from "../images/sponsers/sponser1.webp";
import sponser2 from "../images/sponsers/sponser2.webp";
import sponser4 from "../images/sponsers/sponser4.webp";
import sponser3 from "../images/sponsers/sponser3.webp";
import sponser6 from "../images/sponsers/sponser6.webp";
import sponser7 from "../images/sponsers/sponser7.webp";
import sponser8 from "../images/sponsers/sponser8.webp";
import sponser9 from "../images/sponsers/sponser9.webp";
import sponser10 from "../images/sponsers/sponser10.webp";
import sponser14 from "../images/sponsers/sponser14.webp";
import sponser15 from "../images/sponsers/sponser15.webp";
import sponser16 from "../images/sponsers/sponser16.webp";

const platinum = [
  {
    img: sponser4,
  },
  {
    img: sponser6,
  },
  {
    img: sponser15,
  },
  {
    img: sponser16,
  },
  {
    img: sponser1,
  },
  {
    img: sponser2,
  },
];

const gold = [
  {
    img: sponser7,
  },
  {
    img: sponser14,
  },
  {
    img: sponser3,
  }
];

const partners = [
  {
    img: sponser9,
  },
  {
    img: sponser10,
  },
  {
    img: sponser8,
  },
]

const sponsers = { platinum, gold, partners };
export default sponsers;
